## Set up test project
- The database is located on `DotnetSample.Api/db/product.db` file.
- In case, for some reason, the db file is missing, you can restore it using [database update](https://learn.microsoft.com/en-us/ef/core/managing-schemas/migrations/applying?tabs=dotnet-core-cli#command-line-tools) from `DotnetSample.EFCore` project.

## Set up logger
- On `DotnetSample.Api` project, open `program.cs`.
- Change the following code to change the code
  ```
  builder.Services.AddSingleton<Log.ILogger, Log.ConsoleLogger>();
  ```
- The options are:
  - `Log.ConsoleLogger`.
  - `Log.FileLogger` , the file will be located under `DotnetSample.Api/log` folder.

## Run test project
- Run `DotnetSample.Api` project.
- Everytime a product endpoint is run, it will log a message using the configured logger.
