﻿namespace DotnetSample.Logging
{
    public class FileLogger : ILogger
    {
        private const string FileName = "DotnetSample";
        private readonly string logPath;

        public FileLogger()
        {
            string filePath = Environment.CurrentDirectory;
            logPath = Path.Join(filePath, "log", FileName);
        }

        public void Log(string message)
        {
            File.AppendAllLines($"{logPath}-{DateTime.Now.ToString("yyyyMMdd")}.log", [$"{DateTime.Now.ToString("HH:mm:ss.fff")} : {message}"]);
        }
    }
}
