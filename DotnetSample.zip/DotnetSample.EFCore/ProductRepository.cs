﻿using DotnetSample.Logging;
using Microsoft.EntityFrameworkCore;

namespace DotnetSample.EFCore
{
    public class ProductRepository
    {
        private readonly ProductContext _context;
        private readonly ILogger _logger;

        public ProductRepository(ProductContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public IEnumerable<Product> GetProducts()
        {
            _logger.Log($"Getting all Product...");
            return _context.Products;
        }

        public int AddProducts(Product product)
        {
            var result = _context.Products.Add(product);
            _context.SaveChanges();
            int productId = result.Entity.Id;
            _logger.Log($"Product with id {productId} added");
            return productId;
        }

        public void DeleteProducts(int productId)
        {
            _context.Products.Where(x => x.Id == productId).ExecuteDelete();
            _logger.Log($"Product with id {productId} deleted");
        }
    }
}
