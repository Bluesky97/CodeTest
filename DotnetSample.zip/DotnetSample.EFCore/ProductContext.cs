﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace DotnetSample.EFCore
{
    public class ProductContext : DbContext
    {
        private readonly string dbPath;

        public ProductContext(DbContextOptions options) : base(options)
        {
            string filePath = Environment.CurrentDirectory;
            dbPath = Path.Join(filePath, "database", "products.db");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite($"Data Source={dbPath}");
        }

        public DbSet<Product> Products { get; set; }
    }
}
