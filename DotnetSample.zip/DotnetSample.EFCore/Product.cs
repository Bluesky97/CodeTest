﻿using System.ComponentModel.DataAnnotations;

namespace DotnetSample.EFCore
{
    public class Product
    {
        [Key]
        public required int Id { get; set; }
        public required string Name { get; set; }
        public required decimal Price { get; set; }
    }
}
