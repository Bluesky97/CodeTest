﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DotnetSample.Wpf.ViewModels
{
    public class ContentViewModel : ViewModelBase
    {
        private string _content;
        public string Content
        {
            get => _content;
            set => SetProperty(ref _content, value);
        }

        private readonly DelegateCommand _changeNameCommand;
        public ICommand ChangeContentCommand => _changeNameCommand;

        public ContentViewModel()
        {
            _changeNameCommand = new DelegateCommand(OnChangeContent);
        }

        private void OnChangeContent(object commandParameter)
        {
            Content = "zxc";
        }
    }
}
