﻿using DotnetSample.Api.ProductDto;
using DotnetSample.EFCore;

namespace DotnetSample.Api
{
    public static class ProductApis
    {
        public static RouteGroupBuilder MapProductsApi(this RouteGroupBuilder group)
        {
            group.MapGet("/", (ProductRepository productRepository) => productRepository.GetProducts());
            group.MapPost("/add", (AddProductDto product, ProductRepository productRepository) => productRepository.AddProducts(product.ToProduct()));
            group.MapDelete("/delete", (int productId, ProductRepository productRepository) => productRepository.DeleteProducts(productId));

            return group.WithTags("Products");
        }
    }
}
