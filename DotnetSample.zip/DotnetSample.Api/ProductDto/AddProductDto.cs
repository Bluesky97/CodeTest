﻿using DotnetSample.EFCore;

namespace DotnetSample.Api.ProductDto
{
    public class AddProductDto
    {
        public required string Name { get; set; }
        public required decimal Price { get; set; }

        public Product ToProduct()
        {
            return new Product()
            {
                Id = 0,
                Name = Name,
                Price = Price
            };
        }
    }
}
