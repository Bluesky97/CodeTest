﻿using System.ComponentModel;
using System.Windows.Input;
using System.Windows;

public class MainViewModel : INotifyPropertyChanged
{
    private string _textBoxContent;

    public string TextBoxContent
    {
        get { return _textBoxContent; }
        set
        {
            if (_textBoxContent != value)
            {
                _textBoxContent = value;
                OnPropertyChanged(nameof(TextBoxContent));
            }
        }
    }

    public ICommand ShowMessageBoxCommand { get; }

    public MainViewModel()
    {
        ShowMessageBoxCommand = new RelayCommand(ShowMessageBox);
    }

    private void ShowMessageBox()
    {
        MessageBox.Show(TextBoxContent, "Content from TextBox");
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
